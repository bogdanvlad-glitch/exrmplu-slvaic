# NEXAIA Website

Site statique multi-pages prêt pour GitHub Pages.

## Structure
- index.html
- services.html
- method.html
- use-cases.html
- security.html
- contact.html
- assets/styles.css
- assets/app.js
- assets/favicon.svg
- assets/nexaia.png

## Utilisation
Placez tout le dossier dans votre dépôt GitHub, puis activez GitHub Pages.
